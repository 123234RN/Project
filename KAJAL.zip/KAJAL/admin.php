<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['emailid'])) {
    header("Location: login.php");
    exit();
}
?>

<?php
include 'db_connection.php';

// Update vote count when a user votes
if (isset($_POST['vote'])) {
    $voted_candidate = mysqli_real_escape_string($conn, $_POST['vote']);

    // Update the count for the voted candidate
    $sql_update_vote = "UPDATE vote SET $voted_candidate = $voted_candidate + 1";
    $result_update_vote = mysqli_query($conn, $sql_update_vote);
    if (!$result_update_vote) {
        echo "Error updating vote count: " . mysqli_error($conn);
    }
}

// Retrieve vote counts for each candidate
$sql_get_vote_counts = "SELECT candidate1, candidate2, candidate3, candidate4 FROM vote";
$result_get_vote_counts = mysqli_query($conn, $sql_get_vote_counts);
if (!$result_get_vote_counts) {
    echo "Error retrieving vote counts: " . mysqli_error($conn);
    exit();
}
$row = mysqli_fetch_assoc($result_get_vote_counts);
$candidate1 = $row['candidate1'];
$candidate2 = $row['candidate2'];
$candidate3 = $row['candidate3'];
$candidate4 = $row['candidate4'];
?>
<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Admin page</title>
        <style>
            body {
            /* Set background image */
            background-image: url('image.avif');
            /* Adjust background image properties */
            background-size: cover; /* Cover the entire viewport */
            background-position: center; /* Center the background image */
            background-repeat: no-repeat; /* Do not repeat the background image */
            /* Optionally, you can add a background color as a fallback */
            background-color: #f8f8f8; /* Fallback background color */
            /* Add additional styles as needed */
        }
            .topnav {
        background-color: grey;
        overflow: hidden;
        padding: 25px;
        position: relative;
    }

    h1 {
        margin: 0;
        flex: 1;
        
        color: #333; /* Optional: Specify text color */
    }

    .dropdown {
        position: absolute;
        top: 40%;
        transform: translateY(-50%);
        right: 10px;
        background-color: coral /* Background color for the dropdown button */
        color: #fff; /* Text color for the dropdown button */
        padding: 10px 20px; /* Add padding to make the button more clickable */
        border: none; /* Remove border */
        border-radius: 5px; /* Add border radius for rounded corners */
        cursor: pointer;
        transition: background-color 0.3s ease; /* Smooth transition for hover effec */
        font-weight: bold;
    }

.dropbtn {
    background-color: Earthy oranges; /* Background color for the dropdown button */
    color: black; /* Text color for the dropdown button */
    padding: 10px 20px; /* Add padding to make the button more clickable */
    border: none; /* Remove border */
    border-radius: 5px; /* Add border radius for rounded corners */
    cursor: pointer;
    transition: background-color 0.3s ease; /* Smooth transition for hover effect */
    font-weight: bold;
}
    .dropdown:hover {
        background-color:#FAEBD7 /* Background color for the dropdown button on hover */
    }

    .dropdown-content {
        display: none;
        position: absolute;
        background-color: pink;
        min-width: 160px;
        z-index: 1;
        font-size: 21px;
    }

    .dropdown-content a {
        color: black;
        padding: 0px 16px;
        text-decoration: none;
        display: block;
    }

    .dropdown-content a:hover {
        background-color: MintCream;
    }

        .dropdown:hover .dropdown-content {
            display: block;
        }
        .form-container {
    /* Your existing styles for .form-container */
}

.form-container div {
    margin-top: 20px; /* Adjust spacing between the buttons and other content */
}

.form-container form {
    display: inline-block; /* Display buttons inline */
}

.form-container button {
    padding: 10px 20px; /* Adjust button padding */
    margin-right: 10px; /* Add space between buttons */
    background-color: #4CAF50; /* Green background color */
    color: white; /* Text color */
    border: none; /* Remove border */
    border-radius: 5px; /* Add border radius */
    cursor: pointer;
    transition: background-color 0.3s ease; /* Smooth transition for hover effect */
}

.form-container button:hover {
    background-color: #45a049; /* Darker green color on hover */
}

        .form-container {
    max-width: 600px; /* Adjust max-width as needed */
    margin: 20px auto; /* Center the container horizontally */
    padding: 20px;
    background-color: white;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.vote-table-container {
    margin-top: 20px; /* Adjust spacing from the heading */
}

.vote-table-container table {
    width: 100%; /* Make the table fill the container width */
    border-collapse: collapse; /* Collapse table borders */
}

.vote-table-container th, .vote-table-container td {
    padding: 10px; /* Add padding to cells */
    border: 1px solid black; /* Add borders to cells */
    text-align: left; /* Align text to the left */
}

.vote-table-container th {
    background-color: white /* Light gray background for header cells */
}

.vote-table-container tr {
    background-color: white/* Alternate row background color */
}

.vote-table-container th, .vote-table-container td {
    width: 50%; /* Equal width for both columns */
}

        </style>
    </head>
    <body>
        <div class="topnav">
            <div class="container" id="T1">
                <h2> Admin Page </h2>
                <div class="dropdown">
                    <button class="dropbtn">Dropdown</button>
                    <div class="dropdown-content">
                    <a href="profile.php" style="font-weight: bold;">My Profile</a>
                    <a href="logout.php" style="font-weight: bold;">Logout</a>

                    </div>
                </div>
            </div>
        </div>

        <div class="form-container">
        <!-- Add buttons to enable/disable voting -->
        <div>
            <form action="enable_voting.php" method="post">
                <button type="submit" name="enable_voting">Enable Voting</button>
            </form>
            <form action="disable_voting.php" method="post">
                <button type="submit" name="disable_voting">Disable Voting</button>
            </form>
        </div>

        <div class="form-container">
        <h2>Search</h2>
        <form id="searchForm">
            <input type="text" id="searchInput" name="search" placeholder="Search">
            <button type="submit" id="searchCandidateBtn">Absolute Search</button>
            <button type="submit" id="relativeSearchBtn">Relative Search</button>
        </form>
    </div>

   
<script>
    // Script for searching candidates
    document.getElementById('searchForm').addEventListener('submit', function(event) {
        event.preventDefault();
        
        var searchInput = document.getElementById('searchInput').value.trim().toLowerCase();
        var candidateRows = document.getElementsByClassName('candidateRow');

        // Reset display for all candidate rows
        for (var i = 0; i < candidateRows.length; i++) {
            candidateRows[i].style.display = '';
        }

        // Check which button was clicked
        if (event.submitter.id === 'searchCandidateBtn') {
            // Searching for candidate by name or vote count
            for (var i = 0; i < candidateRows.length; i++) {
                var candidateName = candidateRows[i].getAttribute('data-candidate').toLowerCase();
                var candidateVotes = parseInt(candidateRows[i].querySelector('td:last-child').textContent);
                
                // Check if the search input matches either the candidate name or the votes
                if (candidateName !== searchInput && candidateVotes !== parseInt(searchInput)) {
                    candidateRows[i].style.display = 'none';
                }
            }
        } else if (event.submitter.id === 'relativeSearchBtn') {
            // Relative search
            for (var i = 0; i < candidateRows.length; i++) {
                var candidateName = candidateRows[i].getAttribute('data-candidate').toLowerCase();
                var candidateVotes = parseInt(candidateRows[i].querySelector('td:last-child').textContent);

                // Check if the search input matches either the candidate name or the votes
                if (!candidateName.includes(searchInput) && candidateVotes !== parseInt(searchInput)) {
                    candidateRows[i].style.display = 'none';
                }
            }
        }
    });
</script>

    <!-- Vote Counts Table -->
    <div class="form-container">
        <h2>Vote Counts</h2>
        <div class="vote-table-container">
            <table border="1" id="voteTable">
                <tr>
                    <th>Candidate</th>
                    <th>Votes</th>
                </tr>
                <tr class="candidateRow" data-candidate="Candidate 1">
                    <td>Candidate 1</td>
                    <td><?php echo $candidate1; ?></td>
                </tr>
                <tr class="candidateRow" data-candidate="Candidate 2">
                    <td>Candidate 2</td>
                    <td><?php echo $candidate2; ?></td>
                </tr>
                <tr class="candidateRow" data-candidate="Candidate 3">
                    <td>Candidate 3</td>
                    <td><?php echo $candidate3; ?></td>
                </tr>
                <tr class="candidateRow" data-candidate="Candidate 4">
                    <td>Candidate 4</td>
                    <td><?php echo $candidate4; ?></td>
                </tr>
            </table>
        </div>
    </div>


</body>
</html>
