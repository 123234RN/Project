
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login page</title>
    <link href = "style.css" rel="stylesheet">
</head>
<body>
    

    <div class="form-container">
        <form action="" method="POST">
            
       
            <?php
include("db_connection.php");

if (isset($_POST['emailid'])) {
    $emailid = mysqli_real_escape_string($conn, $_POST['emailid']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    $sql = "SELECT * FROM users WHERE emailid = '$emailid' AND password = '$password'";
    $result = mysqli_query($conn, $sql);
    $count = mysqli_num_rows($result);

    if ($count == 1) {
        $row = mysqli_fetch_assoc($result);
        session_start();
        $_SESSION['emailid'] = $emailid;
        
        // Check if the user is an admin
        if ($row['role'] == 'admin') {
            header("Location: admin.php"); // Redirect admin to admin page
        } else {
            header("Location: voting.php"); // Redirect user to voting page
        }
        exit();
    } else {
        echo "<p style='color: red;'>Invalid Emailid or Password.</p>";

            
    }
}

?>
          <h3>Login Now</h3>         
                    <input type="text"  name="emailid" required placeholder="Enter your Emailid"><br>
                
                    
                    <input type="password"  name="password" required placeholder="Enter your password"><br>
                
                    <input type="submit" name="submit" value="Login now" class="form-btn">
                    <p>Don't have an account? <a href="register.php">Register now</a></p>
                    

                   
                    
                </form>
              
    </div>
</body>
</html>