<?php
include("db_connection.php");

session_start();

// Check if user is logged in, if not redirect to login page
if(!isset($_SESSION['emailid'])) {
    header("Location: login.php");
    exit();
}

$emailid = $_SESSION['emailid'];

$sql = "SELECT * FROM users WHERE emailid = '$emailid'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) == 1) {
    $row = mysqli_fetch_assoc($result);
    $emailid = $row['emailid'];
    $password = $row['password'];
    $username = $row['username'];
    $phonenumber = $row['phonenumber'];

    // Fetch other user information here if needed
} else {
    // Handle error if user not found
    echo "emailid not found!";
}

mysqli_close($conn);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title> Profile </title>
        <style>
            .topnav {
            background-color: crimson;
            overflow: hidden;
            padding: 30px;
            position: relative;
        }

        h1 {
            margin: 0;
            flex: 1;
        }

        .dropdown {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            right: 10px;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            background-color: #f9f9f9;
            min-width: 160px;
            z-index: 1;
        }

        .dropdown-content a {
            color: black;
            padding: 0px 16px;
            text-decoration: none;
            display: block;
        }

        .dropdown-content a:hover {
            background-color: #ddd;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }
             .form-container {
            max-width: 400px;
            margin: 20px auto; /* Add margin for gap */
            padding: 40px;
            background-color: #f9f9f9;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
</style>
</head>
<body>
<div class="topnav">
        <div class="container" id="T1">
            <h1> Voting App </h1>
            <div class="dropdown">
                <button class="dropbtn">Dropdown</button>
                <div class="dropdown-content">
                    <a href="profile.php">My Profile</a>
                    <a href="logout.php">Logout</a>
                </div>
            </div>
        </div>
    </div>
<div class="form-container">
        <h2 style="color: blue;">User Profile</h2>

        <p><strong>Username:</strong> <?php echo $username; ?></p>
        <p><strong>Password:</strong> <?php echo $password; ?></p>
        <p><strong>EmailId:</strong> <?php echo $emailid; ?></p>
        <p><strong>PhoneNumber:</strong> <?php echo $phonenumber; ?></p>
        
        
        <!-- Display other user information here if needed -->
    </div>
</body>
</html>