<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header("Location:login.php");
    exit();
}

// Include the database connection file
include("db_connection.php");

// Check if the connection is established
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data and sanitize
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $candidate1 = isset($_POST['candidate1']) ? 1 : 0; // Check if the checkbox is checked
    $candidate2 = isset($_POST['candidate2']) ? 1 : 0;
    $candidate3 = isset($_POST['candidate3']) ? 1 : 0;
    $candidate4 = isset($_POST['candidate4']) ? 1 : 0;

    // Check if the username already exists
    $check_query = "SELECT * FROM vote WHERE username = '$username'";
    $check_result = mysqli_query($conn, $check_query);

    if (mysqli_num_rows($check_result) > 0) {
        // Username already exists, display a message
        echo '<script>
        alert("You have already voted.");
        window.location.href = "voting.php";
        </script>';
        exit();
    }

    // Insert data into the vote table
    $insert_query = "INSERT INTO vote (username, candidate1, candidate2, candidate3, candidate4) VALUES ('$username', $candidate1, $candidate2, $candidate3, $candidate4)";
    $insert_result = mysqli_query($conn, $insert_query);

    if ($insert_result) {
        // Vote added successfully
        echo '<script>
        alert("Vote added successfully.");
        window.location.href = "voting.php";
        </script>';
    } else {
        // Error adding vote
        echo "Error adding vote: " . mysqli_error($conn);
    }
}

// Close the database connection
mysqli_close($conn);
?>
