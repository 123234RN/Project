<?php
session_start();
include 'db_connection.php';

// Check if the user is logged in
if (!isset($_SESSION['emailid'])) {
    // Redirect the user to the login page if not logged in
    header("Location: login.php");
    exit();
}

$emailid = $_SESSION['emailid'];

// Check if the user has already voted
$sql_check_voted = "SELECT has_voted FROM users WHERE emailid = '$emailid'";
$result_check_voted = mysqli_query($conn, $sql_check_voted);
$row = mysqli_fetch_assoc($result_check_voted);
$has_voted = $row['has_voted'];

// Retrieve voting status from the database
$sql_get_voting_status = "SELECT voting_status FROM vote";
$result_get_voting_status = mysqli_query($conn, $sql_get_voting_status);
$row_voting_status = mysqli_fetch_assoc($result_get_voting_status);
$voting_status = $row_voting_status['voting_status'];

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Voting page</title>
    <style>
         body {
            /* Set background image */
            background-image: url('image.avif');
            /* Adjust background image properties */
            background-size: cover; /* Cover the entire viewport */
            background-position: center; /* Center the background image */
            background-repeat: no-repeat; /* Do not repeat the background image */
            /* Optionally, you can add a background color as a fallback */
            background-color: #f8f8f8; 
            height: 100vh;
        }
         .topnav {
        background-color: grey;
        overflow: hidden;
        padding: 35px;
        position: relative;
    }

    h1 {
        margin: 0;
        flex: 1;
        
        color: #333; /* Optional: Specify text color */
    }

    .dropdown {
        position: absolute;
        top: 40%;
        transform: translateY(-50%);
        right: 10px;
        background-color: coral /* Background color for the dropdown button */
        color: #fff; /* Text color for the dropdown button */
        padding: 10px 20px; /* Add padding to make the button more clickable */
        border: none; /* Remove border */
        border-radius: 5px; /* Add border radius for rounded corners */
        cursor: pointer;
        transition: background-color 0.3s ease; /* Smooth transition for hover effec */
        font-weight: bold;
    }

.dropbtn {
    background-color: Earthy oranges; /* Background color for the dropdown button */
    color: black; /* Text color for the dropdown button */
    padding: 10px 20px; /* Add padding to make the button more clickable */
    border: none; /* Remove border */
    border-radius: 5px; /* Add border radius for rounded corners */
    cursor: pointer;
    transition: background-color 0.3s ease; /* Smooth transition for hover effect */
    font-weight: bold;
}
    .dropdown:hover {
        background-color:#FAEBD7 /* Background color for the dropdown button on hover */
    }

    .dropdown-content {
        display: none;
        position: absolute;
        background-color: pink;
        min-width: 160px;
        z-index: 1;
        font-size: 21px;
    }

    .dropdown-content a {
        color: black;
        padding: 0px 16px;
        text-decoration: none;
        display: block;
    }

    .dropdown-content a:hover {
        background-color: MintCream;
    }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .form-container {
            max-width: 400px;
            margin: 20px auto; /* Add margin for gap */
            padding: 40px;
            background-color: #f9f9f9;
            border-radius: 5px;
            border: 2px solid black; /* Add black border */
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        

        .form-container label {
            display: block;
            margin-bottom: 15px;
            color: #555; /* Change label text color */
        }

        .form-container input[type="checkbox"] {
            margin-right: 10px;
        }

        .form-container button {
            margin-top: 20px;
            background-color: crimson; /* Change button color */
            color: #fff; /* Change button text color */
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .form-container button:hover {
            background-color: #0056b3; /* Change button color on hover */
        }
        .header {
        text-align: center;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
    }

    .header h1 {
        font-size: 40px; /* Adjust the font size as needed */
    }
    </style>
</head>
<body>
    <div class="topnav">
        <div class="container" id="T1">
            <h1> Voting App </h1>
            <div class="dropdown">
                <button class="dropbtn">Dropdown</button>
                <div class="dropdown-content">
                    <a href="profile.php" style="font-weight: bold;">My Profile</a>
                    <a href="logout.php" style="font-weight: bold;">Logout</a>
                </div>
            </div>
        </div>
    </div>

    <?php if ($has_voted): ?>
        <!-- Display a message indicating that the user has already voted -->
        <div class="header"> 
            <h1 style="color: black;">You have already voted.</h1> 
        </div>
        <?php
elseif ($voting_status === 'disabled'):
    // Display a message indicating that voting is closed
?>

    <center><h1 style="color: red;">Voting is currently closed.</h1></center>


<?php
    // Retrieve names of candidates with the most votes
    $sql_get_top_candidate = "SELECT 
        CASE 
            WHEN candidate1 >= candidate2 AND candidate1 >= candidate3 AND candidate1 >= candidate4 THEN 
                CASE 
                    WHEN candidate1 = candidate2 AND candidate1 = candidate3 THEN 'Candidate 1, Candidate 2, Candidate 3'
                    WHEN candidate1 = candidate2 THEN 'Candidate 1, Candidate 2'
                    WHEN candidate1 = candidate3 THEN 'Candidate 1, Candidate 3'
                    WHEN candidate1 = candidate4 THEN 'Candidate 1, Candidate 4'
                    ELSE 'Candidate 1'
                END
            WHEN candidate2 >= candidate1 AND candidate2 >= candidate3 AND candidate2 >= candidate4 THEN 
                CASE 
                    WHEN candidate2 = candidate3 THEN 'Candidate 2, Candidate 3'
                    WHEN candidate2 = candidate4 THEN 'Candidate 2, Candidate 4'
                    ELSE 'Candidate 2'
                END
            WHEN candidate3 >= candidate1 AND candidate3 >= candidate2 AND candidate3 >= candidate4 THEN 
                CASE 
                    WHEN candidate3 = candidate4 THEN 'Candidate 3, Candidate 4'
                    ELSE 'Candidate 3'
                END
            ELSE 'Candidate 4'
        END AS top_candidate
        FROM vote";

    $result_get_top_candidate = mysqli_query($conn, $sql_get_top_candidate);

    // Check if the query was successful
    if ($result_get_top_candidate && mysqli_num_rows($result_get_top_candidate) > 0) {
        $row_top_candidate = mysqli_fetch_assoc($result_get_top_candidate);
        $top_candidate = $row_top_candidate['top_candidate'];
?>
 
    <center><h1 style="color: black;">Highest vote goes to: <?php echo $top_candidate; ?></h1></center>

<?php
    } else {
        echo "Error retrieving top candidate: " . mysqli_error($conn);
    }
?>

    <?php else: ?>
        <!-- Display the voting form -->
        <div class="form-container">
            <form action="" method="POST">
                <label for="candidate1">
                    <input type="radio" class="candidateCheckbox" name="candidate" value="candidate1">
                    CANDIDATE 1
                </label><br>

                <label for="candidate2">
                    <input type="radio" class="candidateCheckbox" name="candidate" value="candidate2">
                    CANDIDATE 2
                </label><br>

                <label for="candidate3">
                    <input type="radio" class="candidateCheckbox" name="candidate" value="candidate3">
                    CANDIDATE 3
                </label><br>

                <label for="candidate4">
                    <input type="radio" class="candidateCheckbox" name="candidate" value="candidate4">
                    CANDIDATE 4
                </label><br>

                <script>
                    const checkboxes = document.querySelectorAll('.candidateCheckbox');

                    checkboxes.forEach((checkbox) => {
                        checkbox.addEventListener('change', function() {
                            checkboxes.forEach((cb) => {
                                if (cb !== checkbox) {
                                    cb.checked = false;
                                }
                            });
                        });
                    });
                </script>

                <button type="submit" name="submit" class="theme-btn btn-style-one button">Vote</button>
            </form>
        </div>
        <?php
    // Handle form submission
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Retrieve form data and sanitize
        $emailid = mysqli_real_escape_string($conn, $_SESSION['emailid']);

        // Initialize vote counts for all candidates
        $candidate1 = 0;
        $candidate2 = 0;
        $candidate3 = 0;
        $candidate4 = 0;

        // Determine which candidate was selected and set its value to 1
        if (isset($_POST['candidate']) && $_POST['candidate'] == 'candidate1') {
            $candidate1 = 1;
        } elseif (isset($_POST['candidate']) && $_POST['candidate'] == 'candidate2') {
            $candidate2 = 1;
        } elseif (isset($_POST['candidate']) && $_POST['candidate'] == 'candidate3') {
            $candidate3 = 1;
        } elseif (isset($_POST['candidate']) && $_POST['candidate'] == 'candidate4') {
            $candidate4 = 1;
        }

        // Update vote counts for the selected candidate in the vote table
        $sql_update_vote = "UPDATE vote SET candidate1 = candidate1 + $candidate1, candidate2 = candidate2 + $candidate2, candidate3 = candidate3 + $candidate3, candidate4 = candidate4 + $candidate4 WHERE id = 1";
        $result_update_vote = mysqli_query($conn, $sql_update_vote);
        if (!$result_update_vote) {
            echo "Error updating vote count: " . mysqli_error($conn);
            exit();
        }

        // Update has_voted column for the user
        $sql_update_has_voted = "UPDATE users SET has_voted = 1 WHERE emailid = '$emailid'";
        $result_update_has_voted = mysqli_query($conn, $sql_update_has_voted);
        if (!$result_update_has_voted) {
            echo "Error updating has_voted column: " . mysqli_error($conn);
            exit();
        }

        // Display success message
        echo "<p style='color: blue;'>Your vote has been added successfully!</p>";
    }
    ?>
    <?php endif; ?>
</body>
</html>
