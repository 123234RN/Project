



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register page</title>
    <link href = "style.css" rel="stylesheet">
</head>
<body>
    
    <div class="form-container">
        <form action="" method="POST">
        <?php
// Include the database connection file
include("db_connection.php");

// Check if the connection is established
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data and sanitize
    $emailid = mysqli_real_escape_string($conn, $_POST['emailid']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $phonenumber = mysqli_real_escape_string($conn, $_POST['phonenumber']);



    // Check if the username already exists
    $check_query = "SELECT * FROM users WHERE emailid = '$emailid'";
    $check_result = mysqli_query($conn, $check_query);

    if (mysqli_num_rows($check_result) > 0) {
        // Username already exists, display a message
        
        
        echo "<p style='color: red;'>Emailid already exists. Please choose another Emailid.</p>";
        
    } else {
        // Insert data into the users table
        $insert_query = "INSERT INTO users (emailid, password, username, phonenumber) VALUES ('$emailid', '$password', '$username', '$phonenumber')";
        $insert_result = mysqli_query($conn, $insert_query);

        if ($insert_result) {
           
            
            echo "<p style='color: blue;'>User added Successfully , You can Login Now.</p>";
        } else {
            echo "Error adding user: " . mysqli_error($conn);
        }
    }

    // Close the database connection
    mysqli_close($conn);
}
?>
            <h3>Register Now</h3>
       
        
            <input type="emailid"  name="emailid" required placeholder="Enter your emailid"><br>
            <input type="password"  name="password" required placeholder="Enter your password"><br>
            <input type="text"  name="username" required placeholder="Enter your name"><br>
            <input type="phonenumber"  name="phonenumber" required placeholder="Enter your phonenumber"><br>
                
                    <input type="submit" name="submit" value="register now" class="form-btn">
                    <p>already have an account? <a href="login.php">Login now</a></p>
                    
                    


                    
                    
                </form>
              
    </div>
</body>
</html>