<?php
include 'db_connection.php';

// Update voting status to 'enabled'
$sql_enable_voting = "UPDATE vote SET voting_status = 'enabled'";
$result_enable_voting = mysqli_query($conn, $sql_enable_voting);

if (!$result_enable_voting) {
    echo "Error enabling voting: " . mysqli_error($conn);
} else {
    echo "Voting enabled successfully";
}

mysqli_close($conn);
?>
