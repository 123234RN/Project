<?php
include 'db_connection.php';

// Update voting status to 'disabled'
$sql_disable_voting = "UPDATE vote SET voting_status = 'disabled'";
$result_disable_voting = mysqli_query($conn, $sql_disable_voting);

if (!$result_disable_voting) {
    echo "Error disabling voting: " . mysqli_error($conn);
} else {
    echo "Voting disabled successfully";
}

mysqli_close($conn);
?>
